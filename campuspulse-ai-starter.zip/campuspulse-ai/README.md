# CampusPulse AI — Full-stack capstone starter

A React/Vite/Tailwind frontend and Java 17/Spring Boot/MySQL backend starter for a smart campus issue reporting application.

## Requirements
- Java 17+
- Maven 3.9+ (or use your IDE's Maven support)
- Node.js 20+
- MySQL 8+ OR Docker and Docker Compose

## Start with Docker
1. Copy `.env.example` to `.env` and change the secrets/passwords.
2. Run `docker compose up --build`.
3. Backend runs at `http://localhost:8080`; health check at `/actuator/health`.
4. Start frontend separately:
   ```bash
   cd frontend
   npm install
   cp .env.example .env
   npm run dev
   ```
5. Open `http://localhost:5173`.

## Start backend without Docker
1. Create a MySQL database named `campuspulse`.
2. Set environment variables `DB_URL`, `DB_USERNAME`, `DB_PASSWORD`, and a strong `JWT_SECRET`.
3. From `backend`, run `mvn spring-boot:run`.

## API overview
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/complaints`
- `GET /api/complaints/mine`
- `GET /api/complaints` (staff/admin)
- `PATCH /api/complaints/{id}/status` (staff/admin)
- `POST /api/ai/classify` (authenticated)
- `GET /actuator/health`

Authentication requests return `{ "token": "...", "user": { "id": 1, "name": "...", "email": "...", "role": "STUDENT" } }`.
Pass the token as `Authorization: Bearer <token>`.

## Important implementation notes
- Public registration deliberately permits only `STUDENT` and `FACULTY`. Provision `STAFF` and `ADMIN` accounts using a secure admin/bootstrap process; never allow a public client to self-register as administrator.
- `/api/ai/classify` currently uses a deterministic keyword-based fallback. It is not a real LLM integration yet. Add an LLM provider via a server-side service, keep API keys in environment variables, and validate model output before using it.
- RAG, provider/department assignment UI, comments, notifications, image uploads, richer analytics, rate limiting, and deployment-specific CORS are extension tasks.
- This is an educational starter, not a production-ready security audit. Review token storage, rate limiting, audit logs, privacy, and error handling before real deployment.
- Do not commit secrets or production credentials.
