import { useEffect, useMemo, useState } from 'react'
import { AlertCircle, CheckCircle2, ClipboardList, GraduationCap, LogOut, Plus, RefreshCw, Search, ShieldCheck, Sparkles } from 'lucide-react'
import api from './api'

const emptyForm = { title: '', description: '', category: 'IT & Wi-Fi', location: '', priority: 'MEDIUM' }
const categories = ['IT & Wi-Fi', 'Classroom Equipment', 'Electrical', 'Plumbing', 'Sanitation', 'Other']
const statuses = ['PENDING', 'IN_PROGRESS', 'RESOLVED', 'REJECTED']

function App() {
  const [token, setToken] = useState(localStorage.getItem('campuspulse_token') || '')
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('campuspulse_user') || 'null'))
  const [authMode, setAuthMode] = useState('login')
  const [auth, setAuth] = useState({ name: '', email: '', password: '', role: 'STUDENT' })
  const [complaints, setComplaints] = useState([])
  const [form, setForm] = useState(emptyForm)
  const [showForm, setShowForm] = useState(false)
  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState('ALL')
  const [notice, setNotice] = useState('')
  const [busy, setBusy] = useState(false)

  const isAdmin = user?.role === 'ADMIN'
  const canManage = ['ADMIN', 'STAFF'].includes(user?.role)

  async function loadComplaints() {
    if (!token) return
    try {
      const response = await api.get(isAdmin || user?.role === 'STAFF' ? '/complaints' : '/complaints/mine')
      setComplaints(response.data)
    } catch (e) {
      setNotice(e.response?.data?.message || 'Could not load complaints. Check that the backend is running.')
    }
  }

  useEffect(() => { loadComplaints() }, [token, user?.role])

  async function submitAuth(e) {
    e.preventDefault(); setBusy(true); setNotice('')
    try {
      const endpoint = authMode === 'login' ? '/auth/login' : '/auth/register'
      const response = await api.post(endpoint, auth)
      localStorage.setItem('campuspulse_token', response.data.token)
      localStorage.setItem('campuspulse_user', JSON.stringify(response.data.user))
      setToken(response.data.token); setUser(response.data.user)
      setNotice('Welcome to CampusPulse AI.')
    } catch (e) {
      setNotice(e.response?.data?.message || 'Authentication failed. Check your details and try again.')
    } finally { setBusy(false) }
  }

  function logout() {
    localStorage.removeItem('campuspulse_token'); localStorage.removeItem('campuspulse_user')
    setToken(''); setUser(null); setComplaints([]); setNotice('')
  }

  async function createComplaint(e) {
    e.preventDefault(); setBusy(true); setNotice('')
    try {
      await api.post('/complaints', form)
      setForm(emptyForm); setShowForm(false); setNotice('Complaint submitted successfully.')
      await loadComplaints()
    } catch (e) {
      setNotice(e.response?.data?.message || 'Could not submit complaint.')
    } finally { setBusy(false) }
  }

  async function updateStatus(id, status) {
    try {
      await api.patch(`/complaints/${id}/status`, { status })
      setNotice(`Complaint status updated to ${status.replace('_', ' ').toLowerCase()}.`)
      await loadComplaints()
    } catch (e) { setNotice(e.response?.data?.message || 'Could not update status.') }
  }

  async function suggestCategory() {
    if (!form.description.trim()) { setNotice('Enter a description first so the assistant can suggest a category.'); return }
    try {
      const response = await api.post('/ai/classify', { description: form.description })
      setForm(prev => ({ ...prev, category: response.data.category || prev.category, priority: response.data.priority || prev.priority }))
      setNotice(`AI suggestion: ${response.data.category || 'category unavailable'} / ${response.data.priority || 'priority unavailable'}. Please review before submitting.`)
    } catch {
      setNotice('AI endpoint is not configured yet. You can select the category and priority manually.')
    }
  }

  const visible = useMemo(() => complaints.filter(c => {
    const matchesQuery = `${c.title} ${c.description} ${c.category} ${c.location}`.toLowerCase().includes(query.toLowerCase())
    return matchesQuery && (filter === 'ALL' || c.status === filter)
  }), [complaints, query, filter])

  if (!token) return <div className="auth-shell">
    <div className="auth-art">
      <div className="brand"><span className="brand-icon"><GraduationCap size={24}/></span> CampusPulse <span className="ai">AI</span></div>
      <div className="hero-copy"><p className="eyebrow">A BETTER CAMPUS STARTS HERE</p><h1>Every issue deserves<br/><span>to be heard.</span></h1><p>Report campus problems, track progress, and help make your campus a better place to learn.</p>
        <div className="feature-pills"><span><CheckCircle2 size={15}/> Transparent tracking</span><span><Sparkles size={15}/> AI-assisted reporting</span></div>
      </div>
      <p className="art-footer">Smart campus issue reporting and resolution</p>
    </div>
    <div className="auth-panel"><form className="auth-card" onSubmit={submitAuth}>
      <div className="mobile-brand brand"><span className="brand-icon"><GraduationCap size={22}/></span> CampusPulse <span className="ai">AI</span></div>
      <p className="eyebrow">{authMode === 'login' ? 'WELCOME BACK' : 'JOIN YOUR CAMPUS COMMUNITY'}</p>
      <h2>{authMode === 'login' ? 'Sign in to your account' : 'Create an account'}</h2>
      <p className="muted">{authMode === 'login' ? 'Continue making your campus better.' : 'Report issues and follow their resolution.'}</p>
      {authMode === 'register' && <><label>Full name</label><input required value={auth.name} onChange={e => setAuth({...auth, name:e.target.value})} placeholder="Your name"/>
        <label>Account role</label><select value={auth.role} onChange={e => setAuth({...auth, role:e.target.value})}><option value="STUDENT">Student</option><option value="FACULTY">Faculty</option></select></>}
      <label>Email address</label><input required type="email" value={auth.email} onChange={e => setAuth({...auth, email:e.target.value})} placeholder="you@college.edu"/>
      <label>Password</label><input required minLength="8" type="password" value={auth.password} onChange={e => setAuth({...auth, password:e.target.value})} placeholder="At least 8 characters"/>
      {notice && <div className="notice"><AlertCircle size={16}/>{notice}</div>}
      <button className="primary-btn full" disabled={busy}>{busy ? 'Please wait…' : authMode === 'login' ? 'Sign in' : 'Create account'}</button>
      <p className="switch-auth">{authMode === 'login' ? "Don't have an account?" : 'Already registered?'} <button type="button" className="link-btn" onClick={() => {setAuthMode(authMode === 'login' ? 'register' : 'login');setNotice('')}}>{authMode === 'login' ? 'Create one' : 'Sign in'}</button></p>
      <p className="tiny">Administrator and staff accounts should be provisioned securely by an administrator.</p>
    </form></div>
  </div>

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><span className="brand-icon"><GraduationCap size={23}/></span> CampusPulse <span className="ai">AI</span></div>
      <div className="side-label">WORKSPACE</div>
      <div className="nav-item active"><ClipboardList size={18}/> Complaints</div>
      <div className="nav-item"><ShieldCheck size={18}/> Issue management</div>
      <div className="sidebar-bottom"><div className="avatar">{(user?.name || 'U').slice(0,1).toUpperCase()}</div><div className="user-meta"><b>{user?.name}</b><span>{user?.role}</span></div><button className="icon-btn" title="Sign out" onClick={logout}><LogOut size={17}/></button></div>
    </aside>
    <main className="main-content">
      <header className="topbar"><div><span className="breadcrumb">Workspace /</span> Complaints</div><div className="top-user"><span className="online-dot"></span> {user?.email}</div></header>
      <section className="page">
        <div className="page-heading"><div><p className="eyebrow">CAMPUS OPERATIONS</p><h1>Complaint dashboard</h1><p className="muted">Track, manage, and resolve campus issues in one place.</p></div><button className="primary-btn" onClick={() => setShowForm(!showForm)}><Plus size={17}/> Report an issue</button></div>
        {notice && <div className="notice notice-wide"><AlertCircle size={16}/><span>{notice}</span><button onClick={() => setNotice('')}>Dismiss</button></div>}
        <div className="stats-grid">
          <Stat title="Total complaints" value={complaints.length} icon={<ClipboardList/>} tone="blue"/>
          <Stat title="Pending" value={complaints.filter(c=>c.status==='PENDING').length} icon={<RefreshCw/>} tone="orange"/>
          <Stat title="In progress" value={complaints.filter(c=>c.status==='IN_PROGRESS').length} icon={<RefreshCw/>} tone="purple"/>
          <Stat title="Resolved" value={complaints.filter(c=>c.status==='RESOLVED').length} icon={<CheckCircle2/>} tone="green"/>
        </div>
        {showForm && <section className="panel form-panel"><div className="panel-heading"><div><h2>Report a campus issue</h2><p className="muted">Give enough detail so the right team can help.</p></div><button className="icon-btn" onClick={()=>setShowForm(false)}>×</button></div>
          <form className="complaint-form" onSubmit={createComplaint}>
            <div className="field"><label>Issue title</label><input required maxLength="120" value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="e.g. Wi-Fi not working in Lab 2"/></div>
            <div className="field"><label>Location</label><input required maxLength="160" value={form.location} onChange={e=>setForm({...form,location:e.target.value})} placeholder="Building, floor, room number"/></div>
            <div className="field"><label>Category</label><select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{categories.map(c=><option key={c}>{c}</option>)}</select></div>
            <div className="field"><label>Suggested priority</label><select value={form.priority} onChange={e=>setForm({...form,priority:e.target.value})}><option>LOW</option><option>MEDIUM</option><option>HIGH</option><option>URGENT</option></select></div>
            <div className="field span-two"><label>Description</label><textarea required minLength="10" rows="4" value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Describe what happened and when you noticed it…"/></div>
            <div className="field span-two ai-hint"><Sparkles size={18}/><div><b>AI reporting assistant</b><p>Get a suggested category and priority from your description.</p></div><button type="button" className="secondary-btn" onClick={suggestCategory}>Suggest with AI</button></div>
            <div className="field span-two form-actions"><button type="button" className="secondary-btn" onClick={()=>setShowForm(false)}>Cancel</button><button className="primary-btn" disabled={busy}>{busy?'Submitting…':'Submit complaint'}</button></div>
          </form>
        </section>}
        <section className="panel"><div className="panel-heading"><div><h2>Recent complaints</h2><p className="muted">Review issue reports and their current status.</p></div><button className="icon-btn" title="Refresh" onClick={loadComplaints}><RefreshCw size={17}/></button></div>
          <div className="toolbar"><div className="search-box"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search complaints…"/></div><select value={filter} onChange={e=>setFilter(e.target.value)}><option value="ALL">All statuses</option>{statuses.map(s=><option key={s} value={s}>{s.replace('_',' ')}</option>)}</select></div>
          <div className="table-wrap"><table><thead><tr><th>Issue</th><th>Category</th><th>Location</th><th>Priority</th><th>Status</th>{canManage&&<th>Update status</th>}</tr></thead><tbody>
            {visible.map(c=><tr key={c.id}><td><b>{c.title}</b><small>{c.description}</small><small className="muted">#{c.id}</small></td><td>{c.category}</td><td>{c.location}</td><td><span className={`priority priority-${(c.priority||'MEDIUM').toLowerCase()}`}>{c.priority}</span></td><td><span className={`status status-${(c.status||'PENDING').toLowerCase()}`}>{(c.status||'PENDING').replace('_',' ')}</span></td>{canManage&&<td><select value={c.status} onChange={e=>updateStatus(c.id,e.target.value)}>{statuses.map(s=><option key={s} value={s}>{s.replace('_',' ')}</option>)}</select></td>}</tr>)}
            {!visible.length&&<tr><td colSpan={canManage?6:5} className="empty"><ClipboardList size={26}/><b>No complaints found</b><span>Try another filter or report a new issue.</span></td></tr>}
          </tbody></table></div>
        </section>
        <footer>CampusPulse AI <span>•</span> Smart campus issue reporting and resolution</footer>
      </section>
    </main>
  </div>
}

function Stat({title,value,icon,tone}) {
  return <div className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div><p>{title}</p><strong>{value}</strong></div></div>
}
export default App
