# CampusPulse AI Frontend

## Requirements
- Node.js 20+
- CampusPulse Spring Boot backend running at `http://localhost:8080`

## Run
```bash
npm install
cp .env.example .env
npm run dev
```
Open http://localhost:5173.

## Notes
- Registration allows STUDENT and FACULTY roles only.
- STAFF and ADMIN accounts must be created securely by an administrator.
- The AI classify endpoint returns a suggestion. If no AI provider is configured, the UI displays a helpful fallback.
