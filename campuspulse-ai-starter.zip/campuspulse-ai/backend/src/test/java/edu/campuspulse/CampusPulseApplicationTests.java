package edu.campuspulse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusPulseApplicationTests {
    @Test void contextLoads() {}
}
