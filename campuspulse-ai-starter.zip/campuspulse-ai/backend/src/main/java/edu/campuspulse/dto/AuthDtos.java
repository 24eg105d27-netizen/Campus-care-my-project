package edu.campuspulse.dto;

import edu.campuspulse.model.Role;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public final class AuthDtos {
    private AuthDtos() {}
    public record RegisterRequest(@NotBlank @Size(max=100) String name,
        @Email @NotBlank @Size(max=180) String email,
        @NotBlank @Size(min=8,max=100) String password,
        Role role) {}
    public record LoginRequest(@Email @NotBlank String email, @NotBlank String password) {}
    public record UserResponse(Long id, String name, String email, Role role) {}
    public record AuthResponse(String token, UserResponse user) {}
}
