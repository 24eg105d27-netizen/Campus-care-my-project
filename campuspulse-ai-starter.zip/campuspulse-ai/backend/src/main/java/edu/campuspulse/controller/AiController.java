package edu.campuspulse.controller;

import edu.campuspulse.dto.ComplaintDtos.*;
import edu.campuspulse.model.Priority;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ai")
public class AiController {
    @PostMapping("/classify")
    public ClassifyResponse classify(@Valid @RequestBody ClassifyRequest request) {
        // Local deterministic fallback. Replace with an LLM API call for production AI.
        String text=request.description().toLowerCase();
        String category="Other"; Priority priority=Priority.MEDIUM; String explanation="Rule-based fallback suggestion; review before submitting.";
        if(text.contains("wifi") || text.contains("internet") || text.contains("network") || text.contains("computer")) category="IT & Wi-Fi";
        else if(text.contains("projector") || text.contains("bench") || text.contains("desk") || text.contains("classroom")) category="Classroom Equipment";
        else if(text.contains("wire") || text.contains("electric") || text.contains("power") || text.contains("light")) category="Electrical";
        else if(text.contains("water") || text.contains("tap") || text.contains("leak") || text.contains("pipe")) category="Plumbing";
        else if(text.contains("garbage") || text.contains("dirty") || text.contains("toilet") || text.contains("clean")) category="Sanitation";
        if(text.contains("fire") || text.contains("sparking") || text.contains("danger") || text.contains("emergency")) priority=Priority.URGENT;
        else if(text.contains("tomorrow") || text.contains("urgent") || text.contains("not working")) priority=Priority.HIGH;
        return new ClassifyResponse(category,priority,explanation);
    }
}
