package edu.campuspulse.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "complaints", indexes = {
    @Index(name = "idx_complaint_status", columnList = "status"),
    @Index(name = "idx_complaint_created", columnList = "createdAt")
})
public class Complaint {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 120) private String title;
    @Column(nullable = false, length = 3000) private String description;
    @Column(nullable = false, length = 80) private String category;
    @Column(nullable = false, length = 160) private String location;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 20) private Priority priority = Priority.MEDIUM;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 20) private ComplaintStatus status = ComplaintStatus.PENDING;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "reporter_id") private AppUser reporter;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "assigned_staff_id") private AppUser assignedStaff;
    @Column(nullable = false) private Instant createdAt = Instant.now();
    @Column(nullable = false) private Instant updatedAt = Instant.now();

    protected Complaint() {}
    public Complaint(String title, String description, String category, String location, Priority priority, AppUser reporter) {
        this.title=title; this.description=description; this.category=category; this.location=location;
        this.priority=priority == null ? Priority.MEDIUM : priority; this.reporter=reporter;
    }
    public void setStatus(ComplaintStatus status){ this.status=status; this.updatedAt=Instant.now(); }
    public void setAssignedStaff(AppUser staff){ this.assignedStaff=staff; this.updatedAt=Instant.now(); }
    public Long getId(){return id;} public String getTitle(){return title;}
    public String getDescription(){return description;} public String getCategory(){return category;}
    public String getLocation(){return location;} public Priority getPriority(){return priority;}
    public ComplaintStatus getStatus(){return status;} public AppUser getReporter(){return reporter;}
    public AppUser getAssignedStaff(){return assignedStaff;} public Instant getCreatedAt(){return createdAt;}
    public Instant getUpdatedAt(){return updatedAt;}
}
