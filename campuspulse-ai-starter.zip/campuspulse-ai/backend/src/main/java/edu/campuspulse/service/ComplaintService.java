package edu.campuspulse.service;

import edu.campuspulse.dto.ComplaintDtos.*;
import edu.campuspulse.model.*;
import edu.campuspulse.repository.*;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class ComplaintService {
    private final ComplaintRepository complaints; private final UserRepository users;
    public ComplaintService(ComplaintRepository complaints, UserRepository users) {
        this.complaints=complaints; this.users=users;
    }
    @Transactional
    public ComplaintResponse create(CreateRequest request, String email) {
        AppUser reporter=users.findByEmail(email).orElseThrow(()->new IllegalArgumentException("User not found"));
        Complaint c=complaints.save(new Complaint(request.title().trim(),request.description().trim(),
            request.category().trim(),request.location().trim(),request.priority(),reporter));
        return map(c);
    }
    @Transactional(readOnly=true)
    public List<ComplaintResponse> mine(String email) {
        return complaints.findByReporterEmailOrderByCreatedAtDesc(email).stream().map(this::map).toList();
    }
    @Transactional(readOnly=true)
    public List<ComplaintResponse> allFor(String email, boolean admin) {
        List<Complaint> list = admin ? complaints.findAllByOrderByCreatedAtDesc()
            : complaints.findByAssignedStaffEmailOrderByCreatedAtDesc(email);
        return list.stream().map(this::map).toList();
    }
    @Transactional
    @CacheEvict(value="complaintStats", allEntries=true)
    public ComplaintResponse updateStatus(Long id, ComplaintStatus status) {
        if(status==null) throw new IllegalArgumentException("Status is required");
        Complaint c=complaints.findById(id).orElseThrow(()->new IllegalArgumentException("Complaint not found"));
        c.setStatus(status);
        return map(c);
    }
    private ComplaintResponse map(Complaint c) {
        return new ComplaintResponse(c.getId(),c.getTitle(),c.getDescription(),c.getCategory(),c.getLocation(),
            c.getPriority(),c.getStatus(),c.getReporter().getId(),c.getReporter().getName(),
            c.getAssignedStaff()==null?null:c.getAssignedStaff().getId(),c.getCreatedAt(),c.getUpdatedAt());
    }
}
