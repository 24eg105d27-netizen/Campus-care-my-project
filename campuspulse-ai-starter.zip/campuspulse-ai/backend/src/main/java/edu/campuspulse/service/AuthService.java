package edu.campuspulse.service;

import edu.campuspulse.dto.AuthDtos.*;
import edu.campuspulse.model.*;
import edu.campuspulse.repository.UserRepository;
import edu.campuspulse.security.JwtService;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {
    private final UserRepository users; private final PasswordEncoder encoder; private final JwtService jwt;
    public AuthService(UserRepository users, PasswordEncoder encoder, JwtService jwt) {
        this.users=users; this.encoder=encoder; this.jwt=jwt;
    }
    @Transactional
    public AuthResponse register(RegisterRequest request) {
        String email=request.email().trim().toLowerCase();
        if(users.existsByEmail(email)) throw new IllegalArgumentException("Email is already registered");
        Role role=request.role()==null ? Role.STUDENT : request.role();
        if(role!=Role.STUDENT && role!=Role.FACULTY)
            throw new IllegalArgumentException("Public registration is only available for STUDENT and FACULTY");
        AppUser user=users.save(new AppUser(request.name().trim(),email,encoder.encode(request.password()),role));
        return response(user);
    }
    public AuthResponse login(LoginRequest request) {
        AppUser user=users.findByEmail(request.email().trim().toLowerCase())
            .orElseThrow(()->new BadCredentialsException("Invalid email or password"));
        if(!encoder.matches(request.password(),user.getPasswordHash()))
            throw new BadCredentialsException("Invalid email or password");
        return response(user);
    }
    private AuthResponse response(AppUser user) {
        return new AuthResponse(jwt.generate(user),new UserResponse(user.getId(),user.getName(),user.getEmail(),user.getRole()));
    }
}
