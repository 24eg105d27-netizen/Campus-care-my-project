package edu.campuspulse.model;
public enum Priority { LOW, MEDIUM, HIGH, URGENT }
