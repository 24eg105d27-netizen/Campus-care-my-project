package edu.campuspulse.dto;

import edu.campuspulse.model.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.time.Instant;

public final class ComplaintDtos {
    private ComplaintDtos() {}
    public record CreateRequest(@NotBlank @Size(max=120) String title,
        @NotBlank @Size(min=10,max=3000) String description,
        @NotBlank @Size(max=80) String category,
        @NotBlank @Size(max=160) String location,
        Priority priority) {}
    public record StatusRequest(ComplaintStatus status) {}
    public record ComplaintResponse(Long id, String title, String description, String category,
        String location, Priority priority, ComplaintStatus status, Long reporterId,
        String reporterName, Long assignedStaffId, Instant createdAt, Instant updatedAt) {}
    public record ClassifyRequest(@NotBlank @Size(max=3000) String description) {}
    public record ClassifyResponse(String category, Priority priority, String explanation) {}
}
