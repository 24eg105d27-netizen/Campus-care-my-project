package edu.campuspulse.controller;

import edu.campuspulse.dto.ComplaintDtos.*;
import edu.campuspulse.model.ComplaintStatus;
import edu.campuspulse.service.ComplaintService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/complaints")
public class ComplaintController {
    private final ComplaintService service;
    public ComplaintController(ComplaintService service){this.service=service;}

    @PostMapping public ComplaintResponse create(@Valid @RequestBody CreateRequest request, Authentication auth) {
        return service.create(request,auth.getName());
    }
    @GetMapping("/mine") public List<ComplaintResponse> mine(Authentication auth) {
        return service.mine(auth.getName());
    }
    @GetMapping @PreAuthorize("hasAnyRole('STAFF','ADMIN')")
    public List<ComplaintResponse> all(Authentication auth) {
        boolean admin=auth.getAuthorities().stream().anyMatch(a->a.getAuthority().equals("ROLE_ADMIN"));
        return service.allFor(auth.getName(),admin);
    }
    @PatchMapping("/{id}/status") @PreAuthorize("hasAnyRole('STAFF','ADMIN')")
    public ComplaintResponse updateStatus(@PathVariable Long id,@Valid @RequestBody StatusRequest request) {
        return service.updateStatus(id,request.status());
    }
}
