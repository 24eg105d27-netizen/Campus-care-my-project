package edu.campuspulse.repository;
import edu.campuspulse.model.*;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ComplaintRepository extends JpaRepository<Complaint, Long> {
    List<Complaint> findAllByOrderByCreatedAtDesc();
    List<Complaint> findByReporterEmailOrderByCreatedAtDesc(String email);
    List<Complaint> findByAssignedStaffEmailOrderByCreatedAtDesc(String email);
}
