package edu.campuspulse.model;
public enum ComplaintStatus { PENDING, IN_PROGRESS, RESOLVED, REJECTED }
