package edu.campuspulse.model;
public enum Role { STUDENT, FACULTY, STAFF, ADMIN }
